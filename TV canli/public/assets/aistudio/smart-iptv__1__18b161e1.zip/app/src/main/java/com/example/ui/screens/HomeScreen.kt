package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Channel
import com.example.ui.MainViewModel
import com.example.ui.components.AddChannelDialog
import com.example.ui.components.ChannelCard
import com.example.ui.components.DeleteNonWorkingDialog
import com.example.ui.player.CustomVideoPlayer
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentRed
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VividPurple

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onSwitchToWeb: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val channels by viewModel.channels.collectAsState()
    val filteredChannels by viewModel.filteredChannels.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val onlyWorkingChannels by viewModel.onlyWorkingChannels.collectAsState()
    val currentPlayingChannel by viewModel.currentPlayingChannel.collectAsState()
    val isFullscreen by viewModel.isPlayerFullscreen.collectAsState()
    val aspectRatioMode by viewModel.aspectRatioMode.collectAsState()

    val totalCount by viewModel.totalChannelsCount.collectAsState()
    val workingCount by viewModel.workingChannelsCount.collectAsState()
    val nonWorkingCount = totalCount - workingCount

    var showAddDialog by remember { mutableStateOf(false) }
    var showDeleteNonWorkingDialog by remember { mutableStateOf(false) }
    var channelToDelete by remember { mutableStateOf<Channel?>(null) }

    // Handle Back Button press
    BackHandler(enabled = isFullscreen || currentPlayingChannel != null) {
        if (isFullscreen) {
            viewModel.setFullscreen(false)
        } else if (currentPlayingChannel != null) {
            viewModel.stopPlaying()
        }
    }

    // Fullscreen video layout
    if (isFullscreen && currentPlayingChannel != null) {
        CustomVideoPlayer(
            channel = currentPlayingChannel!!,
            viewModel = viewModel,
            allChannels = filteredChannels,
            isFullscreen = true,
            aspectRatioMode = aspectRatioMode,
            modifier = Modifier.fillMaxSize()
        )
        return
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = DarkBackground,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = NeonCyan,
                contentColor = Color.Black,
                shape = CircleShape,
                modifier = Modifier.testTag("add_channel_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Kanal əlavə et")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Video Player at Top (Sticky when playing)
            AnimatedVisibility(
                visible = currentPlayingChannel != null,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                currentPlayingChannel?.let { playingChannel ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                            .background(Color.Black)
                    ) {
                        CustomVideoPlayer(
                            channel = playingChannel,
                            viewModel = viewModel,
                            allChannels = filteredChannels,
                            isFullscreen = false,
                            aspectRatioMode = aspectRatioMode,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }

            // Top Header Bar
            Surface(
                color = DarkSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Title and Quick Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Logo & App Name
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        Brush.linearGradient(
                                            listOf(NeonCyan, ElectricBlue)
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Tv,
                                    contentDescription = "Smart IPTV",
                                    tint = Color.Black,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "Smart IPTV",
                                    color = TextPrimary,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = "$totalCount kanal • $workingCount aktiv",
                                    color = AccentGreen,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        // Actions: Delete broken channels & reset
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            // Delete broken channels button
                            IconButton(
                                onClick = { showDeleteNonWorkingDialog = true },
                                modifier = Modifier.testTag("clean_broken_channels_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteSweep,
                                    contentDescription = "İşləməyən kanalları sil",
                                    tint = if (nonWorkingCount > 0) AccentRed else TextMuted
                                )
                            }

                            // Reset to defaults
                            IconButton(
                                onClick = {
                                    viewModel.resetToDefaults()
                                    Toast.makeText(context, "Kanal siyahısı bərpa olundu", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.testTag("reset_channels_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.RestartAlt,
                                    contentDescription = "Sıfırla",
                                    tint = TextSecondary
                                )
                            }

                            // Switch to Web Site Version
                            if (onSwitchToWeb != null) {
                                IconButton(
                                    onClick = onSwitchToWeb,
                                    modifier = Modifier.testTag("switch_to_web_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Public,
                                        contentDescription = "Veb Sayta Keç",
                                        tint = NeonCyan
                                    )
                                }
                            }
                        }
                    }

                    // Search Input
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.setSearchQuery(it) },
                        placeholder = {
                            Text(
                                "Kanal, ölkə və ya növ axtarışı...",
                                color = TextMuted,
                                fontSize = 13.sp
                            )
                        },
                        leadingIcon = {
                            Icon(
                                Icons.Default.Search,
                                contentDescription = "Axtarış",
                                tint = NeonCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                    Icon(
                                        Icons.Default.Clear,
                                        contentDescription = "Təmizlə",
                                        tint = TextSecondary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.12f),
                            focusedContainerColor = DarkSurfaceVariant,
                            unfocusedContainerColor = DarkSurfaceVariant,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_channels_input")
                    )

                    // Categories Horizontal Row
                    val categories = listOf(
                        "Hamısı",
                        "Seçilmişlər",
                        "Azərbaycan",
                        "Türkiyə",
                        "Xəbər",
                        "İdman",
                        "Musiqi",
                        "Uşaq",
                        "Sənədli"
                    )

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(categories) { category ->
                            val isSelected = selectedCategory == category
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.setSelectedCategory(category) },
                                label = {
                                    Text(
                                        text = category,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = DarkSurfaceVariant,
                                    labelColor = TextSecondary,
                                    selectedContainerColor = NeonCyan.copy(alpha = 0.2f),
                                    selectedLabelColor = NeonCyan
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    borderColor = Color.White.copy(alpha = 0.1f),
                                    selectedBorderColor = NeonCyan
                                ),
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }

                    // Only working channels filter toggle row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(AccentGreen, CircleShape)
                            )
                            Text(
                                text = "Yalnız işləyən kanalları göstər",
                                color = TextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Switch(
                            checked = onlyWorkingChannels,
                            onCheckedChange = { viewModel.toggleOnlyWorkingChannels() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.Black,
                                checkedTrackColor = NeonCyan,
                                uncheckedThumbColor = TextMuted,
                                uncheckedTrackColor = DarkSurfaceVariant
                            ),
                            modifier = Modifier.testTag("only_working_switch")
                        )
                    }
                }
            }

            // Channel List / Grid
            if (filteredChannels.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            Icons.Default.Tv,
                            contentDescription = "Kanal tapılmadı",
                            tint = TextMuted,
                            modifier = Modifier.size(54.dp)
                        )
                        Text(
                            text = "Uyğun kanal tapılmadı",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = if (onlyWorkingChannels) {
                                "Yalnız işləyən kanallar filtri aktivdir. Bütün kanalları görmək üçün filtri deaktiv edə və ya axtarışı dəyişə bilərsiniz."
                            } else {
                                "Axtarış meyarlarını dəyişin və ya yeni kanal əlavə edin."
                            },
                            color = TextMuted,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 155.dp),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredChannels, key = { it.id }) { channel ->
                        val isPlaying = currentPlayingChannel?.id == channel.id
                        ChannelCard(
                            channel = channel,
                            isPlaying = isPlaying,
                            onPlayClick = { viewModel.playChannel(channel) },
                            onFavoriteToggle = { viewModel.toggleFavorite(channel.id) },
                            onDeleteClick = {
                                channelToDelete = channel
                            }
                        )
                    }
                }
            }
        }
    }

    // Add Channel Dialog
    if (showAddDialog) {
        AddChannelDialog(
            onDismiss = { showAddDialog = false },
            onAddChannel = { name, url, category, country ->
                viewModel.addCustomChannel(name, url, category, country)
                Toast.makeText(context, "$name əlavə edildi", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Delete non-working dialog
    if (showDeleteNonWorkingDialog) {
        DeleteNonWorkingDialog(
            nonWorkingCount = nonWorkingCount,
            onDismiss = { showDeleteNonWorkingDialog = false },
            onConfirm = {
                val removed = viewModel.deleteAllNonWorkingChannels()
                Toast.makeText(context, "$removed işləməyən kanal silindi", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Delete single channel confirmation dialog
    channelToDelete?.let { targetChannel ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { channelToDelete = null },
            containerColor = DarkSurface,
            title = {
                Text(
                    text = "Kanalı Sil",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(
                    text = "\"${targetChannel.name}\" kanalını silmək istədiyinizə əminsiniz?",
                    color = TextSecondary,
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                androidx.compose.material3.Button(
                    onClick = {
                        viewModel.deleteChannel(targetChannel.id)
                        channelToDelete = null
                        Toast.makeText(context, "${targetChannel.name} silindi", Toast.LENGTH_SHORT).show()
                    },
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = AccentRed,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Sil", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(
                    onClick = { channelToDelete = null }
                ) {
                    Text("Ləğv et", color = TextSecondary)
                }
            }
        )
    }
}
