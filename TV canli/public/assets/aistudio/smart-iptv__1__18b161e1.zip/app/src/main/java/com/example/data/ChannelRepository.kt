package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class ChannelRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("iptv_channels_prefs", Context.MODE_PRIVATE)

    private val _channels = MutableStateFlow<List<Channel>>(emptyList())
    val channels: StateFlow<List<Channel>> = _channels.asStateFlow()

    init {
        loadChannels()
    }

    private fun loadChannels() {
        val jsonStr = prefs.getString("saved_channels_json", null)
        if (jsonStr.isNullOrEmpty()) {
            _channels.value = DefaultChannels.list
            saveChannels(_channels.value)
        } else {
            try {
                val array = JSONArray(jsonStr)
                val list = mutableListOf<Channel>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        Channel(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            name = obj.optString("name", "Kanal"),
                            streamUrl = obj.optString("streamUrl", ""),
                            logoUrl = obj.optString("logoUrl", ""),
                            category = obj.optString("category", "Azərbaycan"),
                            country = obj.optString("country", "🇦🇿 Azərbaycan"),
                            quality = obj.optString("quality", "HD"),
                            isFavorite = obj.optBoolean("isFavorite", false),
                            isWorking = obj.optBoolean("isWorking", true),
                            isCustom = obj.optBoolean("isCustom", false)
                        )
                    )
                }
                if (list.isEmpty()) {
                    _channels.value = DefaultChannels.list
                    saveChannels(_channels.value)
                } else {
                    _channels.value = list
                }
            } catch (e: Exception) {
                _channels.value = DefaultChannels.list
                saveChannels(_channels.value)
            }
        }
    }

    private fun saveChannels(list: List<Channel>) {
        try {
            val array = JSONArray()
            for (ch in list) {
                val obj = JSONObject().apply {
                    put("id", ch.id)
                    put("name", ch.name)
                    put("streamUrl", ch.streamUrl)
                    put("logoUrl", ch.logoUrl)
                    put("category", ch.category)
                    put("country", ch.country)
                    put("quality", ch.quality)
                    put("isFavorite", ch.isFavorite)
                    put("isWorking", ch.isWorking)
                    put("isCustom", ch.isCustom)
                }
                array.put(obj)
            }
            prefs.edit().putString("saved_channels_json", array.toString()).apply()
        } catch (e: Exception) {
            // Log or ignore
        }
    }

    fun deleteChannel(channelId: String) {
        val updated = _channels.value.filterNot { it.id == channelId }
        _channels.value = updated
        saveChannels(updated)
    }

    /**
     * Fulfills user requirement: "acilmayan kanallari da sil"
     * Deletes all channels marked as not working.
     */
    fun deleteAllNonWorkingChannels(): Int {
        val countBefore = _channels.value.size
        val updated = _channels.value.filter { it.isWorking }
        val removed = countBefore - updated.size
        _channels.value = updated
        saveChannels(updated)
        return removed
    }

    fun markChannelWorkingStatus(channelId: String, isWorking: Boolean) {
        val updated = _channels.value.map {
            if (it.id == channelId) it.copy(isWorking = isWorking) else it
        }
        _channels.value = updated
        saveChannels(updated)
    }

    fun toggleFavorite(channelId: String) {
        val updated = _channels.value.map {
            if (it.id == channelId) it.copy(isFavorite = !it.isFavorite) else it
        }
        _channels.value = updated
        saveChannels(updated)
    }

    fun addChannel(name: String, streamUrl: String, category: String, country: String, quality: String = "HD") {
        val newChannel = Channel(
            id = "custom_${System.currentTimeMillis()}",
            name = name.trim(),
            streamUrl = streamUrl.trim(),
            logoUrl = "",
            category = category.trim().ifEmpty { "Azərbaycan" },
            country = country.trim().ifEmpty { "Özəl" },
            quality = quality,
            isFavorite = true,
            isWorking = true,
            isCustom = true
        )
        val updated = listOf(newChannel) + _channels.value
        _channels.value = updated
        saveChannels(updated)
    }

    fun resetToDefaults() {
        _channels.value = DefaultChannels.list
        saveChannels(DefaultChannels.list)
    }
}
