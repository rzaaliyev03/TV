package com.example.ui.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentRed
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun DeleteNonWorkingDialog(
    nonWorkingCount: Int,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        icon = {
            Icon(
                Icons.Default.DeleteSweep,
                contentDescription = "Təmizlə",
                tint = AccentRed,
                modifier = Modifier.size(36.dp)
            )
        },
        title = {
            Text(
                text = "İşləməyən Kanalları Sil",
                color = TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Text(
                text = if (nonWorkingCount > 0) {
                    "Hazırda açılmayan $nonWorkingCount kanal siyahıdan birdəfəlik silinəcək. Davam etmək istəyirsiniz?"
                } else {
                    "Hazırda bütün kanallar aktivdir və ya işləməyən kanal tapılmadı. İstənilən vaxt təkrar yoxlaya bilərsiniz."
                },
                color = TextSecondary,
                fontSize = 14.sp
            )
        },
        confirmButton = {
            if (nonWorkingCount > 0) {
                Button(
                    onClick = {
                        onConfirm()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AccentRed,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("confirm_delete_non_working_button")
                ) {
                    Text("Bəli, Sil", fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                colors = ButtonDefaults.textButtonColors(contentColor = TextSecondary)
            ) {
                Text(if (nonWorkingCount > 0) "Ləğv et" else "Bağla")
            }
        }
    )
}
