package com.example.data

import com.example.data.model.Channel

object DefaultChannels {
    val list: List<Channel> = listOf(
        // Azərbaycan Kanalları
        Channel(
            id = "az_baku_tv",
            name = "Baku TV",
            streamUrl = "https://rtmp.baku.tv/hls/bakutv.m3u8",
            logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/6/61/Baku_TV_logo.svg/300px-Baku_TV_logo.svg.png",
            category = "Azərbaycan",
            country = "🇦🇿 Azərbaycan",
            quality = "1080p",
            isFavorite = true,
            isWorking = true
        ),
        Channel(
            id = "az_atv",
            name = "Azad TV (ATV)",
            streamUrl = "https://lives.atv.az:5443/ATV_TV_STREAM/streams/atvcanli.m3u8",
            logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/0/07/Azad_Az%C9%99rbaycan_TV_logo.png/320px-Azad_Az%C9%99rbaycan_TV_logo.png",
            category = "Azərbaycan",
            country = "🇦🇿 Azərbaycan",
            quality = "1080p",
            isFavorite = true,
            isWorking = true
        ),
        Channel(
            id = "az_apa_tv",
            name = "APA TV",
            streamUrl = "http://stream.apa.tv/apastream/index.m3u8",
            logoUrl = "https://apa.tv/images/logo.png",
            category = "Azərbaycan",
            country = "🇦🇿 Azərbaycan",
            quality = "HD",
            isFavorite = false,
            isWorking = true
        ),
        Channel(
            id = "az_kanal_s",
            name = "Kanal S",
            streamUrl = "https://lives.atv.az:5443/KANAL-S/streams/kanals.m3u8",
            logoUrl = "",
            category = "Azərbaycan",
            country = "🇦🇿 Azərbaycan",
            quality = "HD",
            isFavorite = false,
            isWorking = true
        ),
        Channel(
            id = "az_el_tv",
            name = "EL TV",
            streamUrl = "https://live.eltv.az/live/eltv/playlist.m3u8",
            logoUrl = "",
            category = "Azərbaycan",
            country = "🇦🇿 Azərbaycan",
            quality = "HD",
            isFavorite = false,
            isWorking = true
        ),
        Channel(
            id = "az_kapaz_tv",
            name = "Kəpəz TV",
            streamUrl = "http://85.132.78.122:8050/hls/stream/index.m3u8",
            logoUrl = "",
            category = "Azərbaycan",
            country = "🇦🇿 Azərbaycan",
            quality = "HD",
            isFavorite = false,
            isWorking = true
        ),
        Channel(
            id = "az_gunaz_tv",
            name = "GunAz TV",
            streamUrl = "https://tv.gunaz.tv/hls/live.m3u8",
            logoUrl = "",
            category = "Azərbaycan",
            country = "🇦🇿 Azərbaycan",
            quality = "HD",
            isFavorite = false,
            isWorking = true
        ),
        Channel(
            id = "az_ayaz_tv",
            name = "Ayaz TV",
            streamUrl = "https://janya-ayaztv.vgcdn.net/ptnr-WebApp/title-Ayaz_TV/v1/vglive-sk-934820/main.m3u8",
            logoUrl = "",
            category = "Azərbaycan",
            country = "🇦🇿 Azərbaycan",
            quality = "720p",
            isFavorite = false,
            isWorking = true
        ),

        // Türkiyə Kanalları
        Channel(
            id = "tr_trt_haber",
            name = "TRT Haber",
            streamUrl = "https://tv-trthaber.medya.trt.com.tr/master.m3u8",
            logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/TRT_Haber_logo.svg/300px-TRT_Haber_logo.svg.png",
            category = "Xəbər",
            country = "🇹🇷 Türkiyə",
            quality = "1080p",
            isFavorite = true,
            isWorking = true
        ),
        Channel(
            id = "tr_a_haber",
            name = "A Haber",
            streamUrl = "https://rnttwmjcin.turknet.ercdn.net/lcpmvefbyo/ahaber/ahaber.m3u8",
            logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/2/23/A_Haber_logo.svg/300px-A_Haber_logo.svg.png",
            category = "Xəbər",
            country = "🇹🇷 Türkiyə",
            quality = "1080p",
            isFavorite = false,
            isWorking = true
        ),
        Channel(
            id = "tr_a_spor",
            name = "A Spor",
            streamUrl = "https://rnttwmjcin.turknet.ercdn.net/lcpmvefbyo/aspor/aspor.m3u8",
            logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/A_Spor_logo.svg/300px-A_Spor_logo.svg.png",
            category = "İdman",
            country = "🇹🇷 Türkiyə",
            quality = "1080p",
            isFavorite = true,
            isWorking = true
        ),
        Channel(
            id = "tr_a2_tv",
            name = "A2 TV",
            streamUrl = "https://rnttwmjcin.turknet.ercdn.net/lcpmvefbyo/a2tv/a2tv.m3u8",
            logoUrl = "",
            category = "Türkiyə",
            country = "🇹🇷 Türkiyə",
            quality = "1080p",
            isFavorite = false,
            isWorking = true
        ),
        Channel(
            id = "tr_trt_world",
            name = "TRT World",
            streamUrl = "https://tv-trtworld.medya.trt.com.tr/master.m3u8",
            logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d7/TRT_World_logo.svg/300px-TRT_World_logo.svg.png",
            category = "Xəbər",
            country = "🇹🇷 Türkiyə",
            quality = "1080p",
            isFavorite = false,
            isWorking = true
        ),
        Channel(
            id = "tr_24_tv",
            name = "24 TV",
            streamUrl = "https://turkmedya-live.ercdn.net/tv24/tv24.m3u8",
            logoUrl = "",
            category = "Xəbər",
            country = "🇹🇷 Türkiyə",
            quality = "720p",
            isFavorite = false,
            isWorking = true
        ),
        Channel(
            id = "tr_360_tv",
            name = "360 TV",
            streamUrl = "https://turkmedya-live.ercdn.net/tv360/tv360.m3u8",
            logoUrl = "",
            category = "Türkiyə",
            country = "🇹🇷 Türkiyə",
            quality = "720p",
            isFavorite = false,
            isWorking = true
        ),
        Channel(
            id = "tr_aksu_tv",
            name = "Aksu TV",
            streamUrl = "https://live.artidijitalmedya.com/artidijital_aksutv/aksutv/playlist.m3u8",
            logoUrl = "",
            category = "Türkiyə",
            country = "🇹🇷 Türkiyə",
            quality = "720p",
            isFavorite = false,
            isWorking = true
        ),
        Channel(
            id = "tr_alanya_posta",
            name = "Alanya Posta TV",
            streamUrl = "https://api-tv3.yayin.com.tr/postatv/postatv/playlist.m3u8",
            logoUrl = "",
            category = "Türkiyə",
            country = "🇹🇷 Türkiyə",
            quality = "1080p",
            isFavorite = false,
            isWorking = true
        ),

        // Musiqi
        Channel(
            id = "tr_trt_muzik",
            name = "TRT Müzik",
            streamUrl = "https://tv-trtmuzik.medya.trt.com.tr/master.m3u8",
            logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/TRT_M%C3%BCzik_logo.svg/300px-TRT_M%C3%BCzik_logo.svg.png",
            category = "Musiqi",
            country = "🇹🇷 Türkiyə",
            quality = "1080p",
            isFavorite = true,
            isWorking = true
        ),
        Channel(
            id = "az_kn_music",
            name = "KN Music TV",
            streamUrl = "https://cdn4.yayin.com.tr/kntv/tracks-v1a1/mono.m3u8",
            logoUrl = "",
            category = "Musiqi",
            country = "🇦🇿 Azərbaycan",
            quality = "HD",
            isFavorite = false,
            isWorking = true
        ),

        // Uşaq
        Channel(
            id = "tr_trt_cocuk",
            name = "TRT Çocuk",
            streamUrl = "https://tv-trtcocuk.medya.trt.com.tr/master.m3u8",
            logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/0/07/TRT_%C3%87ocuk_logo.svg/300px-TRT_%C3%87ocuk_logo.svg.png",
            category = "Uşaq",
            country = "🇹🇷 Türkiyə",
            quality = "1080p",
            isFavorite = true,
            isWorking = true
        ),

        // İdman
        Channel(
            id = "intl_redbull_tv",
            name = "Red Bull TV",
            streamUrl = "https://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master.m3u8",
            logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/0/07/Red_Bull_logo.svg/320px-Red_Bull_logo.svg.png",
            category = "İdman",
            country = "🌍 Dünya",
            quality = "1080p",
            isFavorite = true,
            isWorking = true
        ),

        // Xəbər & Dünya
        Channel(
            id = "intl_dw_news",
            name = "DW News English",
            streamUrl = "https://dwamdstream102.akamaized.net/hls/live/2015525/dwstream102/index.m3u8",
            logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Deutsche_Welle_logo.svg/300px-Deutsche_Welle_logo.svg.png",
            category = "Xəbər",
            country = "🌍 Dünya",
            quality = "1080p",
            isFavorite = false,
            isWorking = true
        ),

        // Sənədli & Elm
        Channel(
            id = "intl_nasa_tv",
            name = "NASA TV HD",
            streamUrl = "https://ntv1.akamaized.net/hls/live/2014075/NASA-NTV1-HLS/master.m3u8",
            logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/NASA_logo.svg/300px-NASA_logo.svg.png",
            category = "Sənədli",
            country = "🌍 Dünya",
            quality = "HD",
            isFavorite = false,
            isWorking = true
        )
    )
}
