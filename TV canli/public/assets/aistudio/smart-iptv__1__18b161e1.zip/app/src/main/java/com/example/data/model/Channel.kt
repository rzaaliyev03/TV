package com.example.data.model

data class Channel(
    val id: String,
    val name: String,
    val streamUrl: String,
    val logoUrl: String = "",
    val category: String = "Azərbaycan",
    val country: String = "🇦🇿 Azərbaycan",
    val quality: String = "HD",
    val isFavorite: Boolean = false,
    val isWorking: Boolean = true,
    val isCustom: Boolean = false
)
