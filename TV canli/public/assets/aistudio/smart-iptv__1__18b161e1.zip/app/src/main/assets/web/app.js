// Smart IPTV Web Application
// Default verified channels list
const DEFAULT_CHANNELS = [
  // Azərbaycan
  {
    id: "az_baku_tv",
    name: "Baku TV",
    streamUrl: "https://rtmp.baku.tv/hls/bakutv.m3u8",
    logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/6/61/Baku_TV_logo.svg/300px-Baku_TV_logo.svg.png",
    category: "Azərbaycan",
    country: "🇦🇿 Azərbaycan",
    quality: "1080p",
    isFavorite: true,
    isWorking: true
  },
  {
    id: "az_atv",
    name: "Azad TV (ATV)",
    streamUrl: "https://lives.atv.az:5443/ATV_TV_STREAM/streams/atvcanli.m3u8",
    logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/07/Azad_Az%C9%99rbaycan_TV_logo.png/320px-Azad_Az%C9%99rbaycan_TV_logo.png",
    category: "Azərbaycan",
    country: "🇦🇿 Azərbaycan",
    quality: "1080p",
    isFavorite: true,
    isWorking: true
  },
  {
    id: "az_apa_tv",
    name: "APA TV",
    streamUrl: "http://stream.apa.tv/apastream/index.m3u8",
    logoUrl: "https://apa.tv/images/logo.png",
    category: "Azərbaycan",
    country: "🇦🇿 Azərbaycan",
    quality: "HD",
    isFavorite: false,
    isWorking: true
  },
  {
    id: "az_kanal_s",
    name: "Kanal S",
    streamUrl: "https://lives.atv.az:5443/KANAL-S/streams/kanals.m3u8",
    logoUrl: "",
    category: "Azərbaycan",
    country: "🇦🇿 Azərbaycan",
    quality: "HD",
    isFavorite: false,
    isWorking: true
  },
  {
    id: "az_el_tv",
    name: "EL TV",
    streamUrl: "https://live.eltv.az/live/eltv/playlist.m3u8",
    logoUrl: "",
    category: "Azərbaycan",
    country: "🇦🇿 Azərbaycan",
    quality: "HD",
    isFavorite: false,
    isWorking: true
  },
  {
    id: "az_kapaz_tv",
    name: "Kəpəz TV",
    streamUrl: "http://85.132.78.122:8050/hls/stream/index.m3u8",
    logoUrl: "",
    category: "Azərbaycan",
    country: "🇦🇿 Azərbaycan",
    quality: "HD",
    isFavorite: false,
    isWorking: true
  },
  {
    id: "az_gunaz_tv",
    name: "GunAz TV",
    streamUrl: "https://tv.gunaz.tv/hls/live.m3u8",
    logoUrl: "",
    category: "Azərbaycan",
    country: "🇦🇿 Azərbaycan",
    quality: "HD",
    isFavorite: false,
    isWorking: true
  },
  {
    id: "az_ayaz_tv",
    name: "Ayaz TV",
    streamUrl: "https://janya-ayaztv.vgcdn.net/ptnr-WebApp/title-Ayaz_TV/v1/vglive-sk-934820/main.m3u8",
    logoUrl: "",
    category: "Azərbaycan",
    country: "🇦🇿 Azərbaycan",
    quality: "720p",
    isFavorite: false,
    isWorking: true
  },

  // Türkiyə
  {
    id: "tr_trt_haber",
    name: "TRT Haber",
    streamUrl: "https://tv-trthaber.medya.trt.com.tr/master.m3u8",
    logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/TRT_Haber_logo.svg/300px-TRT_Haber_logo.svg.png",
    category: "Xəbər",
    country: "🇹🇷 Türkiyə",
    quality: "1080p",
    isFavorite: true,
    isWorking: true
  },
  {
    id: "tr_a_haber",
    name: "A Haber",
    streamUrl: "https://rnttwmjcin.turknet.ercdn.net/lcpmvefbyo/ahaber/ahaber.m3u8",
    logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/2/23/A_Haber_logo.svg/300px-A_Haber_logo.svg.png",
    category: "Xəbər",
    country: "🇹🇷 Türkiyə",
    quality: "1080p",
    isFavorite: false,
    isWorking: true
  },
  {
    id: "tr_a_spor",
    name: "A Spor",
    streamUrl: "https://rnttwmjcin.turknet.ercdn.net/lcpmvefbyo/aspor/aspor.m3u8",
    logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/A_Spor_logo.svg/300px-A_Spor_logo.svg.png",
    category: "İdman",
    country: "🇹🇷 Türkiyə",
    quality: "1080p",
    isFavorite: true,
    isWorking: true
  },
  {
    id: "tr_a2_tv",
    name: "A2 TV",
    streamUrl: "https://rnttwmjcin.turknet.ercdn.net/lcpmvefbyo/a2tv/a2tv.m3u8",
    logoUrl: "",
    category: "Türkiyə",
    country: "🇹🇷 Türkiyə",
    quality: "1080p",
    isFavorite: false,
    isWorking: true
  },
  {
    id: "tr_trt_world",
    name: "TRT World",
    streamUrl: "https://tv-trtworld.medya.trt.com.tr/master.m3u8",
    logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d7/TRT_World_logo.svg/300px-TRT_World_logo.svg.png",
    category: "Xəbər",
    country: "🇹🇷 Türkiyə",
    quality: "1080p",
    isFavorite: false,
    isWorking: true
  },
  {
    id: "tr_24_tv",
    name: "24 TV",
    streamUrl: "https://turkmedya-live.ercdn.net/tv24/tv24.m3u8",
    logoUrl: "",
    category: "Xəbər",
    country: "🇹🇷 Türkiyə",
    quality: "720p",
    isFavorite: false,
    isWorking: true
  },
  {
    id: "tr_360_tv",
    name: "360 TV",
    streamUrl: "https://turkmedya-live.ercdn.net/tv360/tv360.m3u8",
    logoUrl: "",
    category: "Türkiyə",
    country: "🇹🇷 Türkiyə",
    quality: "720p",
    isFavorite: false,
    isWorking: true
  },
  {
    id: "tr_aksu_tv",
    name: "Aksu TV",
    streamUrl: "https://live.artidijitalmedya.com/artidijital_aksutv/aksutv/playlist.m3u8",
    logoUrl: "",
    category: "Türkiyə",
    country: "🇹🇷 Türkiyə",
    quality: "720p",
    isFavorite: false,
    isWorking: true
  },
  {
    id: "tr_alanya_posta",
    name: "Alanya Posta TV",
    streamUrl: "https://api-tv3.yayin.com.tr/postatv/postatv/playlist.m3u8",
    logoUrl: "",
    category: "Türkiyə",
    country: "🇹🇷 Türkiyə",
    quality: "1080p",
    isFavorite: false,
    isWorking: true
  },

  // Musiqi
  {
    id: "tr_trt_muzik",
    name: "TRT Müzik",
    streamUrl: "https://tv-trtmuzik.medya.trt.com.tr/master.m3u8",
    logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/TRT_M%C3%BCzik_logo.svg/300px-TRT_M%C3%BCzik_logo.svg.png",
    category: "Musiqi",
    country: "🇹🇷 Türkiyə",
    quality: "1080p",
    isFavorite: true,
    isWorking: true
  },
  {
    id: "az_kn_music",
    name: "KN Music TV",
    streamUrl: "https://cdn4.yayin.com.tr/kntv/tracks-v1a1/mono.m3u8",
    logoUrl: "",
    category: "Musiqi",
    country: "🇦🇿 Azərbaycan",
    quality: "HD",
    isFavorite: false,
    isWorking: true
  },

  // Uşaq
  {
    id: "tr_trt_cocuk",
    name: "TRT Çocuk",
    streamUrl: "https://tv-trtcocuk.medya.trt.com.tr/master.m3u8",
    logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/07/TRT_%C3%87ocuk_logo.svg/300px-TRT_%C3%87ocuk_logo.svg.png",
    category: "Uşaq",
    country: "🇹🇷 Türkiyə",
    quality: "1080p",
    isFavorite: true,
    isWorking: true
  },

  // İdman
  {
    id: "intl_redbull_tv",
    name: "Red Bull TV",
    streamUrl: "https://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master.m3u8",
    logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/07/Red_Bull_logo.svg/320px-Red_Bull_logo.svg.png",
    category: "İdman",
    country: "🌍 Dünya",
    quality: "1080p",
    isFavorite: true,
    isWorking: true
  },

  // Xəbər & Dünya
  {
    id: "intl_dw_news",
    name: "DW News English",
    streamUrl: "https://dwamdstream102.akamaized.net/hls/live/2015525/dwstream102/index.m3u8",
    logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Deutsche_Welle_logo.svg/300px-Deutsche_Welle_logo.svg.png",
    category: "Xəbər",
    country: "🌍 Dünya",
    quality: "1080p",
    isFavorite: false,
    isWorking: true
  },

  // Sənədli & Elm
  {
    id: "intl_nasa_tv",
    name: "NASA TV HD",
    streamUrl: "https://ntv1.akamaized.net/hls/live/2014075/NASA-NTV1-HLS/master.m3u8",
    logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/NASA_logo.svg/300px-NASA_logo.svg.png",
    category: "Sənədli",
    country: "🌍 Dünya",
    quality: "HD",
    isFavorite: false,
    isWorking: true
  }
];

class SmartIPTVApp {
  constructor() {
    this.channels = this.loadChannels();
    this.currentChannel = null;
    this.searchQuery = "";
    this.selectedCategory = "Hamısı";
    this.onlyWorking = true;
    this.aspectRatioMode = "fit"; // fit, fill, zoom
    this.hls = null;

    this.cacheDom();
    this.initPlayer();
    this.bindEvents();
    this.render();
  }

  loadChannels() {
    try {
      const data = localStorage.getItem("smart_iptv_channels");
      if (data) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.error("Error loading channels from storage", e);
    }
    this.saveChannels(DEFAULT_CHANNELS);
    return [...DEFAULT_CHANNELS];
  }

  saveChannels(list) {
    try {
      localStorage.setItem("smart_iptv_channels", JSON.stringify(list));
    } catch (e) {
      console.error("Error saving channels to storage", e);
    }
  }

  cacheDom() {
    this.video = document.getElementById("main-video");
    this.playerContainer = document.getElementById("player-container");
    this.playerOverlay = document.getElementById("player-overlay");
    this.currentTitle = document.getElementById("current-title");
    this.currentSub = document.getElementById("current-sub");
    this.channelGrid = document.getElementById("channel-grid");
    this.emptyState = document.getElementById("empty-state");
    this.searchInput = document.getElementById("search-input");
    this.clearSearchBtn = document.getElementById("clear-search-btn");
    this.categoryChips = document.querySelectorAll(".category-bar .chip");
    this.onlyWorkingCheckbox = document.getElementById("only-working-checkbox");
    this.onlyWorkingSwitch = document.getElementById("only-working-switch");
    this.channelCountLabel = document.getElementById("channel-count-label");

    // Player controls
    this.playPauseBtn = document.getElementById("play-pause-btn");
    this.prevBtn = document.getElementById("prev-btn");
    this.nextBtn = document.getElementById("next-btn");
    this.fullscreenBtn = document.getElementById("fullscreen-btn");
    this.pipBtn = document.getElementById("pip-btn");
    this.aspectBtn = document.getElementById("aspect-btn");
    this.closePlayerBtn = document.getElementById("close-player-btn");

    // Player Error Box
    this.playerErrorBox = document.getElementById("player-error-box");
    this.deleteBrokenBtn = document.getElementById("delete-broken-btn");
    this.nextBrokenBtn = document.getElementById("next-broken-btn");
    this.retryBrokenBtn = document.getElementById("retry-broken-btn");

    // Modals
    this.addModal = document.getElementById("add-modal");
    this.openAddModalBtn = document.getElementById("open-add-modal-btn");
    this.cancelAddBtn = document.getElementById("cancel-add-btn");
    this.confirmAddBtn = document.getElementById("confirm-add-btn");

    this.cleanModal = document.getElementById("clean-modal");
    this.openCleanModalBtn = document.getElementById("open-clean-modal-btn");
    this.cancelCleanBtn = document.getElementById("cancel-clean-btn");
    this.confirmCleanBtn = document.getElementById("confirm-clean-btn");
    this.cleanModalText = document.getElementById("clean-modal-text");

    this.resetBtn = document.getElementById("reset-btn");
    this.toastEl = document.getElementById("toast");
  }

  initPlayer() {
    if (Hls.isSupported()) {
      this.hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
        backBufferLength: 60
      });
      this.hls.attachMedia(this.video);

      this.hls.on(Hls.Events.MANIFEST_PARSED, () => {
        this.hideError();
        this.video.play().catch(() => {});
        this.markCurrentWorking(true);
      });

      this.hls.on(Hls.Events.ERROR, (event, data) => {
        if (data.fatal) {
          console.warn("HLS Fatal Error:", data);
          this.showError("Bu kanal açılmır və ya yayım serveri əlçatmazdır.");
          this.markCurrentWorking(false);
        }
      });
    } else if (this.video.canPlayType("application/vnd.apple.mpegurl")) {
      // Native Safari / iOS HLS
      this.video.addEventListener("loadedmetadata", () => {
        this.hideError();
        this.video.play().catch(() => {});
        this.markCurrentWorking(true);
      });
      this.video.addEventListener("error", () => {
        this.showError("Bu kanal açılmır və ya yayım ünvanı aktiv deyil.");
        this.markCurrentWorking(false);
      });
    }
  }

  bindEvents() {
    // Search
    this.searchInput.addEventListener("input", (e) => {
      this.searchQuery = e.target.value.trim().toLowerCase();
      this.clearSearchBtn.style.display = this.searchQuery ? "block" : "none";
      this.render();
    });

    this.clearSearchBtn.addEventListener("click", () => {
      this.searchInput.value = "";
      this.searchQuery = "";
      this.clearSearchBtn.style.display = "none";
      this.render();
    });

    // Categories
    this.categoryChips.forEach((chip) => {
      chip.addEventListener("click", () => {
        this.categoryChips.forEach((c) => c.classList.remove("active"));
        chip.classList.add("active");
        this.selectedCategory = chip.dataset.category;
        this.render();
      });
    });

    // Only Working Switch
    this.onlyWorkingCheckbox.addEventListener("change", (e) => {
      this.onlyWorking = e.target.checked;
      this.onlyWorkingSwitch.classList.toggle("active", this.onlyWorking);
      this.render();
    });

    // Player playback controls
    this.playPauseBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      this.togglePlay();
    });

    this.prevBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      this.playPrev();
    });

    this.nextBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      this.playNext();
    });

    this.fullscreenBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      this.toggleFullscreen();
    });

    this.pipBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      this.togglePiP();
    });

    this.aspectBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      this.cycleAspectRatio();
    });

    this.closePlayerBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      this.stopPlayer();
    });

    // Player Error Actions
    this.deleteBrokenBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      if (this.currentChannel) {
        const name = this.currentChannel.name;
        this.deleteChannel(this.currentChannel.id);
        this.showToast(`"${name}" açılmadığı üçün silindi`);
      }
    });

    this.nextBrokenBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      this.playNext();
    });

    this.retryBrokenBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      if (this.currentChannel) {
        this.playChannel(this.currentChannel.id);
      }
    });

    // Add Channel Modal
    this.openAddModalBtn.addEventListener("click", () => {
      this.addModal.classList.add("active");
    });

    this.cancelAddBtn.addEventListener("click", () => {
      this.addModal.classList.remove("active");
    });

    this.confirmAddBtn.addEventListener("click", () => {
      const name = document.getElementById("add-name-input").value.trim();
      const url = document.getElementById("add-url-input").value.trim();
      const category = document.getElementById("add-category-select").value;
      const country = document.getElementById("add-country-select").value;

      if (!name) {
        alert("Zəhmət olmasa kanalın adını daxil edin.");
        return;
      }
      if (!url || (!url.startsWith("http://") && !url.startsWith("https://"))) {
        alert("Düzgün HLS / M3U8 yayım linki daxil edin.");
        return;
      }

      this.addChannel({
        id: "custom_" + Date.now(),
        name,
        streamUrl: url,
        logoUrl: "",
        category,
        country,
        quality: "HD",
        isFavorite: true,
        isWorking: true,
        isCustom: true
      });

      this.addModal.classList.remove("active");
      document.getElementById("add-name-input").value = "";
      document.getElementById("add-url-input").value = "";
      this.showToast(`"${name}" əlavə edildi`);
    });

    // Clean Broken Modal
    this.openCleanModalBtn.addEventListener("click", () => {
      const brokenCount = this.channels.filter((c) => !c.isWorking).length;
      if (brokenCount === 0) {
        this.cleanModalText.textContent = "Hazırda bütün kanallar aktivdir və ya açılmayan kanal tapılmadı.";
        this.confirmCleanBtn.style.display = "none";
      } else {
        this.cleanModalText.textContent = `Hazırda açılmayan ${brokenCount} kanal siyahıdan birdəfəlik silinəcək. Davam etmək istəyirsiniz?`;
        this.confirmCleanBtn.style.display = "block";
      }
      this.cleanModal.classList.add("active");
    });

    this.cancelCleanBtn.addEventListener("click", () => {
      this.cleanModal.classList.remove("active");
    });

    this.confirmCleanBtn.addEventListener("click", () => {
      const count = this.deleteAllBroken();
      this.cleanModal.classList.remove("active");
      this.showToast(`${count} açılmayan kanal silindi`);
    });

    // Reset to defaults
    this.resetBtn.addEventListener("click", () => {
      if (confirm("Kanal siyahısını ilkin vəziyyətinə qaytarmaq istəyirsiniz?")) {
        this.channels = [...DEFAULT_CHANNELS];
        this.saveChannels(this.channels);
        this.render();
        this.showToast("Kanal siyahısı bərpa olundu");
      }
    });

    // Keyboard Shortcuts (TV Remote friendly)
    window.addEventListener("keydown", (e) => {
      if (document.activeElement.tagName === "INPUT" || document.activeElement.tagName === "SELECT") {
        return;
      }
      if (e.key === " " && this.currentChannel) {
        e.preventDefault();
        this.togglePlay();
      } else if (e.key === "ArrowRight") {
        this.playNext();
      } else if (e.key === "ArrowLeft") {
        this.playPrev();
      } else if (e.key.toLowerCase() === "f") {
        this.toggleFullscreen();
      } else if (e.key === "Escape" && this.currentChannel) {
        this.stopPlayer();
      }
    });
  }

  getFilteredChannels() {
    return this.channels.filter((ch) => {
      const matchesWorking = !this.onlyWorking || ch.isWorking;
      const matchesQuery =
        !this.searchQuery ||
        ch.name.toLowerCase().includes(this.searchQuery) ||
        ch.category.toLowerCase().includes(this.searchQuery) ||
        ch.country.toLowerCase().includes(this.searchQuery);

      const matchesCat =
        this.selectedCategory === "Hamısı"
          ? true
          : this.selectedCategory === "Seçilmişlər"
          ? ch.isFavorite
          : ch.category.toLowerCase() === this.selectedCategory.toLowerCase() ||
            ch.country.toLowerCase().includes(this.selectedCategory.toLowerCase());

      return matchesWorking && matchesQuery && matchesCat;
    });
  }

  render() {
    const filtered = this.getFilteredChannels();
    const workingCount = this.channels.filter((c) => c.isWorking).length;
    this.channelCountLabel.textContent = `${this.channels.length} kanal • ${workingCount} aktiv`;

    if (filtered.length === 0) {
      this.channelGrid.innerHTML = "";
      this.emptyState.classList.add("active");
      return;
    }

    this.emptyState.classList.remove("active");
    this.channelGrid.innerHTML = filtered
      .map((ch) => {
        const isPlaying = this.currentChannel && this.currentChannel.id === ch.id;
        const logoHtml = ch.logoUrl
          ? `<img class="channel-logo-img" src="${ch.logoUrl}" alt="${ch.name}" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';" /><span class="channel-logo-fallback" style="display:none;">${ch.name.charAt(0)}</span>`
          : `<span class="channel-logo-fallback">${ch.name.charAt(0)}</span>`;

        return `
          <div class="channel-card ${isPlaying ? "active-playing" : ""}" data-id="${ch.id}" tabindex="0">
            <div class="card-top">
              <span class="status-badge ${ch.isWorking ? "working" : "broken"}">
                <span class="status-dot"></span>
                ${ch.isWorking ? "Aktiv" : "Açılmır"}
              </span>
              <div class="card-actions">
                <button class="btn-card-action fav ${ch.isFavorite ? "active" : ""}" title="Seçilmiş" data-fav="${ch.id}">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="${ch.isFavorite ? "currentColor" : "none"}" stroke="currentColor" stroke-width="2">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                  </svg>
                </button>
                <button class="btn-card-action delete" title="Kanalı sil" data-del="${ch.id}">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="3 6 5 6 21 6"></polyline>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                  </svg>
                </button>
              </div>
            </div>
            <div class="card-content">
              <div class="channel-logo-wrap">
                ${logoHtml}
              </div>
              <div class="channel-details">
                <div class="channel-name" title="${ch.name}">${ch.name}</div>
                <div class="channel-country">${ch.country} • ${ch.category}</div>
              </div>
            </div>
            <div class="card-bottom">
              <span class="quality-tag">${ch.quality}</span>
              <span class="play-tag">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
                  <polygon points="5 3 19 12 5 21 5 3"></polygon>
                </svg>
                ${isPlaying ? "Oynadılır" : "İzlə"}
              </span>
            </div>
          </div>
        `;
      })
      .join("");

    // Attach card event listeners
    this.channelGrid.querySelectorAll(".channel-card").forEach((card) => {
      const id = card.dataset.id;
      card.addEventListener("click", (e) => {
        if (e.target.closest(".fav")) {
          e.stopPropagation();
          this.toggleFavorite(id);
        } else if (e.target.closest(".delete")) {
          e.stopPropagation();
          const ch = this.channels.find((c) => c.id === id);
          if (confirm(`"${ch ? ch.name : "Kanal"}" silinsin?`)) {
            this.deleteChannel(id);
          }
        } else {
          this.playChannel(id);
        }
      });

      card.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          this.playChannel(id);
        }
      });
    });
  }

  playChannel(id) {
    const ch = this.channels.find((c) => c.id === id);
    if (!ch) return;

    this.currentChannel = ch;
    this.currentTitle.textContent = ch.name;
    this.currentSub.textContent = `${ch.country} • ${ch.category} • ${ch.quality}`;
    this.playerContainer.classList.add("active");
    this.hideError();

    // Scroll player into view smoothly
    this.playerContainer.scrollIntoView({ behavior: "smooth", block: "nearest" });

    if (this.hls) {
      this.hls.loadSource(ch.streamUrl);
    } else {
      this.video.src = ch.streamUrl;
      this.video.load();
    }

    this.render();
  }

  stopPlayer() {
    if (this.hls) {
      this.hls.stopLoad();
    }
    this.video.pause();
    this.video.src = "";
    this.currentChannel = null;
    this.playerContainer.classList.remove("active");
    this.render();
  }

  togglePlay() {
    if (this.video.paused) {
      this.video.play().catch(() => {});
    } else {
      this.video.pause();
    }
  }

  playNext() {
    const filtered = this.getFilteredChannels();
    if (!this.currentChannel || filtered.length === 0) return;
    const idx = filtered.findIndex((c) => c.id === this.currentChannel.id);
    const nextIdx = idx !== -1 && idx < filtered.length - 1 ? idx + 1 : 0;
    this.playChannel(filtered[nextIdx].id);
  }

  playPrev() {
    const filtered = this.getFilteredChannels();
    if (!this.currentChannel || filtered.length === 0) return;
    const idx = filtered.findIndex((c) => c.id === this.currentChannel.id);
    const prevIdx = idx > 0 ? idx - 1 : filtered.length - 1;
    this.playChannel(filtered[prevIdx].id);
  }

  toggleFullscreen() {
    if (!document.fullscreenElement) {
      this.playerContainer.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  }

  togglePiP() {
    if (document.pictureInPictureElement) {
      document.exitPictureInPicture().catch(() => {});
    } else if (document.pictureInPictureEnabled && this.video) {
      this.video.requestPictureInPicture().catch(() => {});
    }
  }

  cycleAspectRatio() {
    if (this.aspectRatioMode === "fit") {
      this.aspectRatioMode = "fill";
      this.video.className = "fill";
      this.aspectBtn.title = "Format: Tam Ekran (Fill)";
    } else if (this.aspectRatioMode === "fill") {
      this.aspectRatioMode = "zoom";
      this.video.className = "zoom";
      this.aspectBtn.title = "Format: Yaxınlaşdırılmış (Zoom)";
    } else {
      this.aspectRatioMode = "fit";
      this.video.className = "";
      this.aspectBtn.title = "Format: Orijinal (Fit)";
    }
    this.showToast(`Format: ${this.aspectRatioMode.toUpperCase()}`);
  }

  showError(message) {
    document.getElementById("error-desc").textContent = message;
    this.playerErrorBox.classList.add("active");
  }

  hideError() {
    this.playerErrorBox.classList.remove("active");
  }

  markCurrentWorking(isWorking) {
    if (!this.currentChannel) return;
    const ch = this.channels.find((c) => c.id === this.currentChannel.id);
    if (ch && ch.isWorking !== isWorking) {
      ch.isWorking = isWorking;
      this.saveChannels(this.channels);
      this.render();
    }
  }

  toggleFavorite(id) {
    const ch = this.channels.find((c) => c.id === id);
    if (ch) {
      ch.isFavorite = !ch.isFavorite;
      this.saveChannels(this.channels);
      this.render();
    }
  }

  deleteChannel(id) {
    const isPlayingCurrent = this.currentChannel && this.currentChannel.id === id;
    this.channels = this.channels.filter((c) => c.id !== id);
    this.saveChannels(this.channels);

    if (isPlayingCurrent) {
      const remaining = this.getFilteredChannels();
      if (remaining.length > 0) {
        this.playChannel(remaining[0].id);
      } else {
        this.stopPlayer();
      }
    }
    this.render();
  }

  deleteAllBroken() {
    const beforeCount = this.channels.length;
    this.channels = this.channels.filter((c) => c.isWorking);
    this.saveChannels(this.channels);
    if (this.currentChannel && !this.currentChannel.isWorking) {
      this.stopPlayer();
    }
    this.render();
    return beforeCount - this.channels.length;
  }

  addChannel(newCh) {
    this.channels.unshift(newCh);
    this.saveChannels(this.channels);
    this.render();
    this.playChannel(newCh.id);
  }

  showToast(message) {
    this.toastEl.textContent = message;
    this.toastEl.classList.add("show");
    setTimeout(() => {
      this.toastEl.classList.remove("show");
    }, 2800);
  }
}

// Bootstrap when DOM ready
document.addEventListener("DOMContentLoaded", () => {
  window.iptvApp = new SmartIPTVApp();
});
