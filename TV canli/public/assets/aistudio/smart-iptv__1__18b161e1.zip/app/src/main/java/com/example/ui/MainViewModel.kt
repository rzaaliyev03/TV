package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ChannelRepository
import com.example.data.model.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

enum class AspectRatioMode {
    FIT, FILL, ZOOM
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val repository = ChannelRepository(application.applicationContext)

    val channels: StateFlow<List<Channel>> = repository.channels

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("Hamısı")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _onlyWorkingChannels = MutableStateFlow(true)
    val onlyWorkingChannels: StateFlow<Boolean> = _onlyWorkingChannels.asStateFlow()

    private val _currentPlayingChannel = MutableStateFlow<Channel?>(null)
    val currentPlayingChannel: StateFlow<Channel?> = _currentPlayingChannel.asStateFlow()

    private val _isPlayerFullscreen = MutableStateFlow(false)
    val isPlayerFullscreen: StateFlow<Boolean> = _isPlayerFullscreen.asStateFlow()

    private val _isPlaying = MutableStateFlow(true)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isBuffering = MutableStateFlow(false)
    val isBuffering: StateFlow<Boolean> = _isBuffering.asStateFlow()

    private val _playerError = MutableStateFlow<String?>(null)
    val playerError: StateFlow<String?> = _playerError.asStateFlow()

    private val _aspectRatioMode = MutableStateFlow(AspectRatioMode.FIT)
    val aspectRatioMode: StateFlow<AspectRatioMode> = _aspectRatioMode.asStateFlow()

    val filteredChannels: StateFlow<List<Channel>> = combine(
        channels,
        _searchQuery,
        _selectedCategory,
        _onlyWorkingChannels
    ) { chList, query, cat, onlyWorking ->
        chList.filter { ch ->
            val matchesWorking = !onlyWorking || ch.isWorking
            val matchesQuery = query.isBlank() ||
                    ch.name.contains(query, ignoreCase = true) ||
                    ch.category.contains(query, ignoreCase = true) ||
                    ch.country.contains(query, ignoreCase = true)
            val matchesCategory = when (cat) {
                "Hamısı" -> true
                "Seçilmişlər" -> ch.isFavorite
                else -> ch.category.equals(cat, ignoreCase = true) || ch.country.contains(cat, ignoreCase = true)
            }
            matchesWorking && matchesQuery && matchesCategory
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalChannelsCount: StateFlow<Int> = combine(channels) { it.first().size }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val workingChannelsCount: StateFlow<Int> = combine(channels) { it.first().count { ch -> ch.isWorking } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(category: String) {
        _selectedCategory.value = category
    }

    fun toggleOnlyWorkingChannels() {
        _onlyWorkingChannels.value = !_onlyWorkingChannels.value
    }

    fun playChannel(channel: Channel) {
        _currentPlayingChannel.value = channel
        _playerError.value = null
        _isPlaying.value = true
        _isBuffering.value = true
    }

    fun stopPlaying() {
        _currentPlayingChannel.value = null
        _playerError.value = null
        _isBuffering.value = false
    }

    fun playNextChannel() {
        val current = _currentPlayingChannel.value ?: return
        val list = filteredChannels.value.ifEmpty { channels.value }
        if (list.isEmpty()) return
        val currentIndex = list.indexOfFirst { it.id == current.id }
        val nextIndex = if (currentIndex != -1 && currentIndex < list.size - 1) currentIndex + 1 else 0
        playChannel(list[nextIndex])
    }

    fun playPreviousChannel() {
        val current = _currentPlayingChannel.value ?: return
        val list = filteredChannels.value.ifEmpty { channels.value }
        if (list.isEmpty()) return
        val currentIndex = list.indexOfFirst { it.id == current.id }
        val prevIndex = if (currentIndex > 0) currentIndex - 1 else list.size - 1
        playChannel(list[prevIndex])
    }

    fun toggleFavorite(channelId: String) {
        repository.toggleFavorite(channelId)
    }

    fun deleteChannel(channelId: String) {
        if (_currentPlayingChannel.value?.id == channelId) {
            playNextChannel()
            if (_currentPlayingChannel.value?.id == channelId) {
                stopPlaying()
            }
        }
        repository.deleteChannel(channelId)
    }

    fun deleteCurrentBrokenChannel() {
        val current = _currentPlayingChannel.value ?: return
        deleteChannel(current.id)
    }

    fun deleteAllNonWorkingChannels(): Int {
        val current = _currentPlayingChannel.value
        val count = repository.deleteAllNonWorkingChannels()
        if (current != null && !current.isWorking) {
            stopPlaying()
        }
        return count
    }

    fun setPlayerBuffering(buffering: Boolean) {
        _isBuffering.value = buffering
    }

    fun setPlayerError(message: String) {
        _playerError.value = message
        _isBuffering.value = false
        _currentPlayingChannel.value?.let { current ->
            repository.markChannelWorkingStatus(current.id, false)
        }
    }

    fun clearPlayerError() {
        _playerError.value = null
        _currentPlayingChannel.value?.let { current ->
            repository.markChannelWorkingStatus(current.id, true)
        }
    }

    fun toggleFullscreen() {
        _isPlayerFullscreen.value = !_isPlayerFullscreen.value
    }

    fun setFullscreen(fullscreen: Boolean) {
        _isPlayerFullscreen.value = fullscreen
    }

    fun cycleAspectRatio() {
        _aspectRatioMode.value = when (_aspectRatioMode.value) {
            AspectRatioMode.FIT -> AspectRatioMode.FILL
            AspectRatioMode.FILL -> AspectRatioMode.ZOOM
            AspectRatioMode.ZOOM -> AspectRatioMode.FIT
        }
    }

    fun addCustomChannel(name: String, streamUrl: String, category: String, country: String) {
        repository.addChannel(name, streamUrl, category, country)
    }

    fun resetToDefaults() {
        repository.resetToDefaults()
    }
}
