package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF070B16)
val DarkSurface = Color(0xFF0F172A)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkSurfaceElevated = Color(0xFF283548)

val NeonCyan = Color(0xFF00E5FF)
val ElectricBlue = Color(0xFF3B82F6)
val VividPurple = Color(0xFF8B5CF6)
val SoftCyan = Color(0xFF67E8F9)

val AccentGreen = Color(0xFF10B981)
val AccentRed = Color(0xFFEF4444)
val AccentAmber = Color(0xFFF59E0B)

val TextPrimary = Color(0xFFF9FAFB)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val BorderOutline = Color(0xFF334155)
