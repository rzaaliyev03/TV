package com.example

import com.example.data.DefaultChannels
import com.example.data.model.Channel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun `default channels are loaded and verified`() {
    val channels = DefaultChannels.list
    assertTrue("Default channels should not be empty", channels.isNotEmpty())
    
    // Check that Azerbaijan channels exist
    val azChannels = channels.filter { it.category == "Azərbaycan" || it.country.contains("Azərbaycan") }
    assertTrue("Azerbaijan channels should be present", azChannels.isNotEmpty())
    assertTrue("Baku TV should exist", channels.any { it.name.contains("Baku", ignoreCase = true) })
    assertTrue("Azad TV should exist", channels.any { it.name.contains("Azad", ignoreCase = true) })

    // Check that stream URLs are valid
    channels.forEach { ch ->
      assertTrue("Channel URL must not be blank for ${ch.name}", ch.streamUrl.isNotBlank())
      assertTrue("Channel URL must be HTTP/HTTPS for ${ch.name}", ch.streamUrl.startsWith("http"))
      assertTrue("Channel name must not be blank", ch.name.isNotBlank())
    }
  }

  @Test
  fun `channel model data manipulation works`() {
    val channel = Channel(
      id = "test_1",
      name = "Test TV",
      streamUrl = "https://example.com/live.m3u8",
      category = "Azərbaycan",
      country = "🇦🇿 Azərbaycan",
      isWorking = true,
      isFavorite = false
    )

    val updatedWorking = channel.copy(isWorking = false)
    assertFalse(updatedWorking.isWorking)

    val updatedFavorite = channel.copy(isFavorite = true)
    assertTrue(updatedFavorite.isFavorite)
  }
}
