# Smart IPTV - Veb Sayt Versiyası (Web Version)

Bu qovluqdakı fayllar **Smart IPTV** tətbiqinin tam müstəqil **Veb Sayt** versiyasıdır.

## 🚀 Fayllar:
- `index.html` - Veb saytın əsas HTML səhifəsi
- `style.css` - Qaranlıq Sinema (Dark Cinema) dizaynı və adaptiv stillər
- `app.js` - Hls.js video pleyer, kateqoriyalar, axtarış, kanalların silinməsi və idarəetmə məntiqi
- `hls.min.js` - Canlı TV yayımlarını (HLS / M3U8) brauzerdə oynadan kitabxana

## 💻 Kompüterdə və ya Brauzerdə necə açmaq olar?
1. `web` qovluğundakı `index.html` faylının üzərinə iki dəfə klikləyərək istənilən brauzerdə (Google Chrome, Microsoft Edge, Mozilla Firefox, Safari) aça bilərsiniz.
2. Və ya sadə bir lokal server ilə işə sala bilərsiniz:
   ```bash
   # Python ilə:
   python3 -m http.server 8080
   # Sonra brauzerdə http://localhost:8080 açın
   ```

## 🌐 İnternetdə (Hosting) Necə Paylaşmaq olar?
Bu qovluqdakı faylları heç bir əlavə quraşdırma olmadan aşağıdakı platformalara ödənişsiz yükləyə bilərsiniz:
1. **Vercel** və ya **Netlify**: Sadəcə `web` qovluğunu sürüşdürüb buraxın (Drag & Drop)
2. **GitHub Pages**: Faylları GitHub repozitoriyasına yükləyib Pages funksiyasını aktivləşdirin
3. **İstənilən Hosting (cPanel / Apache / Nginx)**: `public_html` qovluğuna yükləyin
